LEGION 24 – instalim në iPhone

Përmbajtja:
- index.html: aplikacioni
- manifest.webmanifest: konfigurimi PWA
- sw.js: cache/offline bazë

Instalimi:
1. Ngarko këto 3 skedarë në një host HTTPS (p.sh. GitHub Pages).
2. Hape URL-në në Safari në iPhone.
3. Share -> Add to Home Screen -> Add.
4. Hape ikonën nga Home Screen.

Kujtesat:
- Brenda aplikacionit, Settings -> Krijo kujtesat për Apple Calendar.
- Hap skedarin .ics dhe shto ngjarjet në Calendar.
- Zgjidh alarmet nëse iPhone nuk i importon automatikisht.
- Kujtesat e Calendar punojnë edhe kur app është i mbyllur.

Kufizime:
- Ky paketim nuk është hostuar online dhe nuk mund të instalohet drejtpërdrejt nga skedari ZIP.
- PWA kërkon HTTPS për instalim të qëndrueshëm.
- Të dhënat ruhen lokalisht në shfletues; eksportoji para se të pastrosh të dhënat.

Shënim shëndetësor:
Përdor planin si pikënisje të butë. Në moshën 17 vjeç, mos bëj dieta dobësimi apo stërvitje ekstreme. Ndalo nëse ke dhimbje, marramendje ose lodhje të pazakontë dhe kërko këshillë nga prindi/kujdestari dhe profesionisti shëndetësor.
